/**
 * Created by weibin.zeng on 16/8/23.
 */


var game=game||{};

//if ( ! Detector.webgl ) Detector.addGetWebGLMessage();

documentReady(function(){

    game.stageWidth=document.documentElement.clientWidth||document.body.clientWidth;
    game.stageHeight=document.documentElement.clientHeight||document.body.clientHeight;

    initThree();
});


function initThree(){
    var canvas,
        renderer,
        scene,
        camera,
        controls;

    canvas=document.createElement("canvas");
    document.body.appendChild(canvas);

    renderer=new THREE.WebGLRenderer({
        canvas:canvas
    });
    renderer.setPixelRatio( window.devicePixelRatio );
    renderer.setSize( game.stageWidth, game.stageHeight );
    renderer.setClearColor(0x000);

    scene=new THREE.Scene();

    camera=new THREE.PerspectiveCamera(75,game.stageWidth/game.stageHeight,1,10000);
    camera.position.z = 5;
    camera.lookAt(0,0,0);

    controls=new THREE.OrbitControls(camera,canvas);

    var group = new THREE.Group();
    scene.add( group );

    // lights
    scene.add( new THREE.AmbientLight( 0x444444 ) );
    var light1 = new THREE.DirectionalLight( 0xffffff, 1 );
    light1.position.set( 4, -1, 1 );
    scene.add( light1 );

    var skyM = new THREE.MeshPhongMaterial({
        color: 0x999999,
        emissive: 0x444444,
        side: THREE.BackSide
    });
    var sky = new THREE.Mesh(new THREE.SphereGeometry(10, 50, 50), skyM);
    scene.add(sky);

    var material = new THREE.MeshLambertMaterial( { color : 0x00cc00 } );

    var geometry = new THREE.Geometry();
    geometry.vertices.push( new THREE.Vector3( -1, -1, 0 ) );
    geometry.vertices.push( new THREE.Vector3(  1, -1, 0 ) );
    geometry.vertices.push( new THREE.Vector3(  1,  1, 0 ) );
    var face = new THREE.Face3( 0, 1, 2 );
    geometry.faces.push( face );
    geometry.computeFaceNormals();

    scene.add( new THREE.Mesh( geometry, material ) );

    // 8
    var loader=new THREE.JSONLoader();
    var mesh1;
    var mesh1v=[];
    loader.load("model/0.js",function(g){

        var geometry=g;

        for(var i=0;i<geometry.vertices.length;i++){
            mesh1v.push(geometry.vertices[i].clone());
        }

        var material = new THREE.MeshPhongMaterial({
            color: 0x144c7f,
            specular: 0x3f72cf,
            shininess: 20,
            vertexColors: THREE.FaceColors,
            wireframe: !1,
            shading: THREE.FlatShading
        });

        mesh1=new THREE.Mesh(geometry,material);
        group.add(mesh1);
        mesh1.radius=rand(50,80);
        mesh1.noise=rand(-20,20);
        mesh1.speed=0.1*rand(1,7);
    });

    function rand(a, b, d) {
        d = 0 == d ? !1 : !0;
        a = Math.min(a + Math.random() * (b + 2 - a), b);
        return d ? parseInt(a) : a
    }

    function animate() {

        requestAnimationFrame( animate );

        if(controls)controls.update(); // required if there is damping or if autoRotate = true

        TWEEN.update();

        renderer.render( scene, camera );

        var time = Date.now() * 0.01;
        if(mesh1)
        {
            //mesh1.rotation.y+=0.01;
            for ( var i = 0; i < mesh1.geometry.vertices.length; i ++ )
            {
                var t=Math.sin(i*0.1+time)*0.01;
                mesh1.geometry.vertices[i].x+=((mesh1v[i].x+t)-mesh1.geometry.vertices[i].x)*0.16;
                mesh1.geometry.vertices[i].y+=((mesh1v[i].y+t)-mesh1.geometry.vertices[i].y)*0.16;
                mesh1.geometry.vertices[i].z+=((mesh1v[i].z+t)-mesh1.geometry.vertices[i].z)*0.16;

                mesh1.geometry.verticesNeedUpdate = true;
            }
        }

    }
    animate();
}