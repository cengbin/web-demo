javascript-jpeg-encoder
=======================

JPEG encoder ported to JavaScript and optimized by Andreas Ritter, www.bytestrom.eu, 11/2009.

His site went offline a while ago but I still had a local copy and thought it should stay public for the world's benefit.
