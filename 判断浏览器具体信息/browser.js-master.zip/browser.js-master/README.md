browser.js
==========

判断浏览器和操作系统

版本说明
==========
0.0.1	浏览器支持Firefox/IE/Safari/Opera,操作系统支持Linux/Windows/Macintosh/iPad/iPhone/Android  

使用方法
==========
在html页面的head标签中导入browser.js
全局变量中的browser即为返回值，分别有browser.browser/browser.engine/browser.version/browser.system，分别表示浏览器、引擎、浏览器版本、操作系统。

演示地址
==========
http://labs.simpleapples.com/browser